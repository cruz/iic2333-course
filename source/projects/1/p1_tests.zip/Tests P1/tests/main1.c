#include <stdio.h>
#include <stdlib.h>
#include "cz_API.h"

int main(void){

	char *diskname = "simdiskformat.bin";

	cz_mount(diskname);

	printf("===== ESTADO DE BITMAP =====\n");
	cz_bitmap();
	printf("===== REVISIÓN =====\n");
	printf("Primer output: 5 unos y el resto solo ceros.\n");
	printf("Segundo output: 5.\n");
	printf("Tercer output: 65531.\n");

	// Código guardar buffer

	FILE *example = fopen("test1_example.txt", "rb");
	fseek(example, 0, SEEK_END);
	int size = ftell(example);
	fseek(example, 0, SEEK_SET);
	unsigned char *content = malloc(size * sizeof(unsigned char));
	fread(content, 1, size, example);

	// Test 1

	czFILE* test1 = cz_open("/elohim.txt", 'w');

	int written_bytes = cz_write(test1, content, size);
	int close_state1 = cz_close(test1);

	czFILE* test1_result = cz_open("/elohim.txt", 'r');
	unsigned char* result = malloc(size*sizeof(unsigned char));
	int read_bytes = cz_read(test1_result, result, size);
	int close_state2 = cz_close(test1_result);
	// Se guarda en el servidor para comparar.
	FILE* example_result = fopen("test1_result.txt", "wb");
	fwrite(result, 1, size, example_result);
	fclose(example_result);
	// Vemos el estado del directorio.
	printf("===== ESTADO DE DIRECTORIO =====\n");
	cz_ls("/");
	printf("===== VALORES RESULTANTES  =====\n");
	// Imprimimos los estados de cierre.
	printf("Estado de cierre 1: %i\nEstado de cierre 2: %i\n", close_state1, close_state2);
	// Imprimimos la cantidad de bytes escritos y leidos.
	printf("Cantidad de bytes leidos: %i\nCantidad de bytes escritos: %i\nCantidad original: %i\n", read_bytes, written_bytes, size);
	// Liberamos todo.
	printf("===== ESTADO DE BITMAP =====\n");
	cz_bitmap();
	printf("===== REVISIÓN =====\n");
	printf("Primer output: 7 unos y el resto solo ceros.\n");
	printf("Segundo output: 5.\n");
	printf("Tercer output: 65529.\n");
	free(content);
	free(result);
};
