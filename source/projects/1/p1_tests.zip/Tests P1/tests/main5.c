#include <stdio.h>
#include <stdlib.h>
#include "cz_API.h"

int main(void){

    char *diskname = "simdiskformat.bin";

    cz_mount(diskname);

    int mk_1 = cz_mkdir("/foo");
    int mk_2 = cz_mkdir("/foo/germy");
    int mk_3 = cz_mkdir("/foo/richi");

    // Código inicial para guardar el buffer del ejemplo.
    FILE* example = fopen("test3_example.mp3", "rb");
    fseek(example, 0, SEEK_END);
    int size = ftell(example);
    fseek(example, 0, SEEK_SET);
    unsigned char* content = malloc(size*sizeof(unsigned char));
    fread(content, 1, size, example);
    fclose(example);
    // Test 3.
    // Buscamos un archivo que no existe.
    int exist_state1 = cz_exists("/temon.mp3");
    // Creamos el archivo y lo escribimos en el disco.
    czFILE* test3_example = cz_open("/foo/germy/temon.mp3", 'w');
    int written_bytes = cz_write(test3_example, content, size);
    int close_state1 = cz_close(test3_example);
    czFILE* test3_example2 = cz_open("/foo/richi/temon.mp3", 'w');
    int written_bytes2 = cz_write(test3_example2, content, size);
    int close_state2 = cz_close(test3_example2);
    // Vemos el estado inicial.
    printf("===== ESTADO DE DIRECTORIOS  =====\n");
    printf("===== RAÍZ =====\n");
    cz_ls("/");
    printf("===== RICHI =====\n");
    cz_ls("/foo/richi");
    printf("===== GERMY =====\n");
    cz_ls("/foo/germy");
    // Ahora buscamos un archivo que existe.
    int exist_state2 = cz_exists("/foo/germy/temon.mp3");
    // Copiamos el archivo de forma errónea con el mismo nombre
    int copy_state1 = cz_cp("/foo/germy/temon.mp3", "/foo/richi/temon.mp3");
    // Vemos la lista para verificar que no se haya creado.
    printf("===== ESTADO DE DIRECTORIO RICHI =====\n");
    printf("=====     [SIN CAMBIO]     =====\n");
    cz_ls("/foo/richi");
    // Ahora lo hacemos correctamente.
    int copy_state2 = cz_cp("/foo/richi/temon.mp3", "/foo/germy/cumbia.mp3");
    // Vemos la lista para verificar que se haya creado.
    printf("===== ESTADO DE DIRECTORIO GERMY =====\n");
    cz_ls("/foo/germy");
    // Ahora lo abrimos, lo leemos y lo escribimos de forma binaria en el servidor para ver si se construyó de forma correcta.
    czFILE* test3_copy = cz_open("/foo/germy/cumbia.mp3", 'r');
    unsigned char* result = malloc(size*sizeof(unsigned char));
    int read_bytes = cz_read(test3_copy, result, size);
    int close_state3 = cz_close(test3_copy);
    // Se guarda en el servidor para comparar.
    FILE* example_copy = fopen("test5_copy.mp3", "wb");
    fwrite(result, 1, size, example_copy);
    fclose(example_copy);
    // Ahora, cambiaremos el nombre de la copia. Cambiamos el nombre de forma errónea.
    int move_state1 = cz_mv("/foo/germy/cumbia.mp3", "/foo/germy/temon.mp3");
    // Vemos la lista para verificar que no se cambia el nombre.
    printf("===== ESTADO DE DIRECTORIO GERMY =====\n");
    printf("=====     [SIN CAMBIO]     =====\n");
    cz_ls("/foo/germy");
    // Finalmente, se cambia el nombre correctamente.
    int move_state2 = cz_mv("/foo/germy/cumbia.mp3", "foo/germy/germy.mp3");
    printf("===== ESTADO DE DIRECTORIO GERMY =====\n");
    cz_ls("/foo/germy");
    // Ahora, eliminamos un archivo que no existe.
    int remove_state1 = cz_rm("/foo/richi/not.exe");
    // Vemos la lista para revisar que no haya pasado nada.
    printf("===== ESTADO DE DIRECTORIO RICHI =====\n");
    printf("=====     [SIN CAMBIO]     =====\n");
    cz_ls("/foo/richi");
    // Ahora eliminamos el último archivo creado y vemos la lista.
    int remove_state2 = cz_rm("/foo/germy/germy.mp3");
    printf("===== ESTADO DE DIRECTORIO GERMY =====\n");
    cz_ls("/foo/germy");
    printf("===== VALORES RESULTANTES  =====\n");
    // Imprimimos los estados de creación.
    printf("Estado de creación 1: %i\nEstado de creación 2: %i\nEstado de creación 3: %i\n", mk_1, mk_2, mk_3);
    // Imprimimos los estados de cierre.
    printf("Estado de cierre 1: %i\nEstado de cierre 2: %i\nEstado de cierre 3: %i\n", close_state1, close_state2, close_state3);
    // Imprimimos la cantidad de bytes escritos y leidos.
    printf("Cantidad de bytes leidos: %i\nCantidad de bytes escritos 1: %i\nCantidad de bytes escritos 2: %i\nCantidad original: %i\n", read_bytes, written_bytes,
           written_bytes2, size);
    // Imprimimos los estados de existencia.
    printf("Estado de existencia 1: %i\nEstado de existencia 2: %i\n", exist_state1, exist_state2);
    // Imprimimos los estados de copia.
    printf("Estado de copia 1: %i\nEstado de copia 2: %i\n", copy_state1, copy_state2);
    // Imprimimos los estados de movimiento.
    printf("Estado de movimiento 1: %i\nEstado de movimiento 2: %i\n", move_state1, move_state2);
    // Imprimimos los estados de eliminación.
    printf("Estado de eliminación 1: %i\nEstado de eliminación 2: %i\n", remove_state1, remove_state2);
    // Liberamos todo.
    free(content);
    free(result);
};
