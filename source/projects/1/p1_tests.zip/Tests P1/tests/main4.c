#include <stdio.h>
#include <stdlib.h>
#include "cz_API.h"

int main(void){

	char *diskname = "simdiskformat.bin";

	cz_mount(diskname);

	FILE* example1 = fopen("test2_example1.png", "rb");
	fseek(example1, 0, SEEK_END);
	int size1 = ftell(example1);
	fseek(example1, 0, SEEK_SET);
	unsigned char* content1 = malloc(size1*sizeof(unsigned char));
	fread(content1, 1, size1, example1);
	fclose(example1);

	FILE* example2 = fopen("test2_example2.gif", "rb");
	fseek(example2, 0, SEEK_END);
	int size2 = ftell(example2);
	fseek(example2, 0, SEEK_SET);
	unsigned char* content2 = malloc(size2*sizeof(unsigned char));
	fread(content2, 1, size2, example2);
	fclose(example2);

	int mk_1 = cz_mkdir("/foo");
	int mk_2 = cz_mkdir("/bar");
	int mk_3 = cz_mkdir("/foobar/hello"); // deberia fallar

	printf("===== ESTADO DE DIRECTORIO =====\n");
    printf("=====     dir root   =====\n");
	cz_ls("/");

	czFILE* test2_example1 = cz_open("/foo/doge.png", 'w');
    cz_write(test2_example1, content1, size1);
    cz_close(test2_example1);

    czFILE* test2_example2 = cz_open("/bar/meme.gif", 'w');
    cz_write(test2_example2, content2, size2);
    cz_close(test2_example2);

    printf("===== ESTADO DE DIRECTORIOS =====\n");
    printf("=====        dir foo        =====\n");
    cz_ls("/foo");


    printf("===== ESTADO DE DIRECTORIOS =====\n");
    printf("=====        dir bar        =====\n");
    cz_ls("/bar");

    int exists1 = cz_exists("/foo/doge.png");
    int exists2 = cz_exists("/bar/meme.gif");

    int mv_1 = cz_mvdir("/foo", "/bar"); // deberia fallar
    int mv_2 = cz_mvdir("/foo", "/bar/foo");
    int mv_3 = cz_mvdir("/aaaaa", "/bar/foo"); // deberia fallar

    printf("===== ESTADO DE DIRECTORIOS =====\n");
    printf("=====        dir root       =====\n");
    cz_ls("/");

    printf("===== ESTADO DE DIRECTORIOS =====\n");
    printf("=====        dir bar        =====\n");
    cz_ls("/bar");

    int cp_1 = cz_cpdir("/bar", "/aaaaa/bar"); // deberia fallar
    int cp_2 = cz_cpdir("/bar/foo", "/bar/foo2");
    int cp_3 = cz_cpdir("/aaaaa", "/bar/foo/aaaaa"); // deberia fallar

    printf("===== ESTADO DE DIRECTORIOS =====\n");
    printf("=====        dir bar        =====\n");
    cz_ls("/bar");

    printf("===== ESTADO DE DIRECTORIOS =====\n");
    printf("=====      dir foo       =====\n");
    cz_ls("/bar/foo");

		printf("===== ESTADO DE DIRECTORIOS =====\n");
    printf("=====      dir foo2       =====\n");
    cz_ls("/bar/foo2");

    int rm_1 = cz_rmdir("/foo"); //deberia fallar
    int rm_2 = cz_rmdir("/bar/foo");

    printf("===== ESTADO DE DIRECTORIOS =====\n");
    printf("=====        dir bar        =====\n");
    cz_ls("/bar");

		printf("===== VALORES RESULTANTES  =====\n");
    printf("Estado de creación de directorio (0) 1: %i\n", mk_1);
    printf("Estado de creación de directorio (0) 2: %i\n", mk_2);
    printf("Estado de creación de directorio (!0) 3: %i\n", mk_3);

    printf("Estado de existencia (!0) 1: %i\n", exists1);
    printf("Estado de existencia (!0) 2: %i\n", exists2);

    printf("Estado de movimiento de directorio (!0) 1: %i\n", mv_1);
    printf("Estado de movimiento de directorio (0) 2: %i\n", mv_2);
    printf("Estado de movimiento de directorio (!0) 3: %i\n", mv_3);

    printf("Estado de copia de directorio (!0) 1: %i\n", cp_1);
    printf("Estado de copia de directorio (0) 2: %i\n", cp_2);
    printf("Estado de copia de directorio (!0) 3: %i\n", cp_3);

    printf("Estado de eliminación de directorio (!0) 1: %i\n", rm_1);
    printf("Estado de eliminación de directorio (0) 2: %i\n", rm_2);

    free(content1);
    free(content2);
};
