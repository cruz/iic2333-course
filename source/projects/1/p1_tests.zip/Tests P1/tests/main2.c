#include <stdio.h>
#include <stdlib.h>
#include "cz_API.h"

int main(void){

    char *diskname = "simdiskformat.bin";

    cz_mount(diskname);

    FILE* example1 = fopen("test2_example1.png", "rb");
    fseek(example1, 0, SEEK_END);
    int size1 = ftell(example1);
    fseek(example1, 0, SEEK_SET);
    unsigned char* content1 = malloc(size1*sizeof(unsigned char));
    fread(content1, 1, size1, example1);
    fclose(example1);
    FILE* example2 = fopen("test2_example2.gif", "rb");
    fseek(example2, 0, SEEK_END);
    int size2 = ftell(example2);
    fseek(example2, 0, SEEK_SET);
    unsigned char* content2 = malloc(size2*sizeof(unsigned char));
    fread(content2, 1, size2, example2);
    fclose(example2);
    // Test 2 - Ejemplo 1.
    // Creamos el archivo y lo escribimos en el disco.
    czFILE* test2_example1 = cz_open("/doge.png", 'w');
    int written_bytes1 = cz_write(test2_example1, content1, size1);
    int close_state11 = cz_close(test2_example1);
    // Ahora lo abrimos, lo leemos y lo escribimos de forma binaria en el servidor para ver si se construyó de forma correcta.
    czFILE* test2_result1 = cz_open("/doge.png", 'r');
    unsigned char* result1 = malloc(size1*sizeof(unsigned char));
    int read_bytes1 = cz_read(test2_result1, result1, size1);
    int close_state12 = cz_close(test2_result1);
    // Se guarda en el servidor para comparar.
    FILE* example_result1 = fopen("test2_result1.png", "wb");
    fwrite(result1, 1, size1, example_result1);
    fclose(example_result1);
    // Vemos el estado del directorio.
    printf("===== ESTADO DE DIRECTORIO RAÍZ =====\n");
    cz_ls("/");
    printf("===== VALORES RESULTANTES ARCHIVO 1 =====\n");
    // Imprimimos los estados de cierre.
    printf("Estado de cierre 1: %i\nEstado de cierre 2: %i\n", close_state11, close_state12);
    // Imprimimos la cantidad de bytes escritos y leidos.
    printf("Cantidad de bytes leidos: %i\nCantidad de bytes escritos: %i\nCantidad original: %i\n", read_bytes1, written_bytes1, size1);
    // Test 2 - Ejemplo 2.
    // Creamos el archivo y lo escribimos en el disco.
    czFILE* test2_example2 = cz_open("/meme.gif", 'w');
    int written_bytes2 = cz_write(test2_example2, content2, size2);
    int close_state21 = cz_close(test2_example2);
    // Ahora lo abrimos, lo leemos y lo escribimos de forma binaria en el servidor para ver si se construyó de forma correcta.
    czFILE* test2_result2 = cz_open("/meme.gif", 'r');
    unsigned char* result2 = malloc(size2*sizeof(unsigned char));
    int read_bytes2 = cz_read(test2_result2, result2, size2);
    int close_state22 = cz_close(test2_result2);
    // Se guarda en el servidor para comparar.
    FILE* example_result2 = fopen("test2_result2.gif", "wb");
    fwrite(result2, 1, size2, example_result2);
    fclose(example_result2);
    // Vemos el estado del directorio.
    printf("===== ESTADO DE DIRECTORIO RAÍZ =====\n");
    cz_ls("/");
    printf("===== VALORES RESULTANTES ARCHIVO 2 =====\n");
    // Imprimimos los estados de cierre.
    printf("Estado de cierre 1: %i\nEstado de cierre 2: %i\n", close_state21, close_state22);
    // Imprimimos la cantidad de bytes escritos y leidos.
    printf("Cantidad de bytes leidos: %i\nCantidad de bytes escritos: %i\nCantidad original: %i\n", read_bytes2, written_bytes2, size2);
    // Liberamos todo.
    free(content1);
    free(result1);
    free(content2);
    free(result2);
};
