#include <stdio.h>
#include <stdlib.h>
#include "cz_API.h"

int main(void){
  
    char *diskname = "simdiskformat.bin";

    cz_mount(diskname);

    // Código inicial para guardar el buffer del ejemplo.
    FILE* example = fopen("test3_example.mp3", "rb");
    fseek(example, 0, SEEK_END);
    int size = ftell(example);
    fseek(example, 0, SEEK_SET);
    unsigned char* content = malloc(size*sizeof(unsigned char));
    fread(content, 1, size, example);
    fclose(example);
    // Test 3.
    // Buscamos un archivo que no existe.
    int exist_state1 = cz_exists("/temon.mp3");
    // Creamos el archivo y lo escribimos en el disco.
    czFILE* test3_example = cz_open("/temon.mp3", 'w');
    int written_bytes = cz_write(test3_example, content, size);
    int close_state1 = cz_close(test3_example);
    // Vemos el estado inicial.
    printf("===== ESTADO DE DIRECTORIO RAÍZ =====\n");
    cz_ls("/");
    // Ahora buscamos un archivo que existe.
    int exist_state2 = cz_exists("/temon.mp3");
    // Copiamos el archivo de forma errónea con el mismo nombre
    int copy_state1 = cz_cp("/temon.mp3", "/temon.mp3");
    // Vemos la lista para verificar que no se haya creado.
    printf("===== ESTADO DE DIRECTORIO RAÍZ =====\n");
    printf("=====     [SIN CAMBIO]     =====\n");
    cz_ls("/");
    // Ahora lo hacemos correctamente.
    int copy_state2 = cz_cp("/temon.mp3", "/cumbia.mp3");
    // Vemos la lista para verificar que se haya creado.
    printf("===== ESTADO DE DIRECTORIO RAÍZ =====\n");
    cz_ls("/");
    // Ahora lo abrimos, lo leemos y lo escribimos de forma binaria en el servidor para ver si se construyó de forma correcta.
    czFILE* test3_copy = cz_open("/cumbia.mp3", 'r');
    unsigned char* result = malloc(size*sizeof(unsigned char));
    int read_bytes = cz_read(test3_copy, result, size);
    int close_state2 = cz_close(test3_copy);
    // Se guarda en el servidor para comparar.
    FILE* example_copy = fopen("test3_copy.mp3", "wb");
    fwrite(result, 1, size, example_copy);
    fclose(example_copy);
    // Ahora, cambiaremos el nombre de la copia. Cambiamos el nombre de forma errónea.
    int move_state1 = cz_mv("/cumbia.mp3", "/temon.mp3");
    // Vemos la lista para verificar que no se cambia el nombre.
    printf("===== ESTADO DE DIRECTORIO RAÍZ =====\n");
    printf("=====     [SIN CAMBIO]     =====\n");
    cz_ls("/");
    // Finalmente, se cambia el nombre correctamente.
    int move_state2 = cz_mv("/cumbia.mp3", "/germy.mp3");
    printf("===== ESTADO DE DIRECTORIO RAÍZ =====\n");
    cz_ls("/");
    // Ahora, eliminamos un archivo que no existe.
    int remove_state1 = cz_rm("/not.exe");
    // Vemos la lista para revisar que no haya pasado nada.
    printf("===== ESTADO DE DIRECTORIO RAÍZ =====\n");
    printf("=====     [SIN CAMBIO]     =====\n");
    cz_ls("/");
    // Ahora eliminamos el último archivo creado y vemos la lista.
    int remove_state2 = cz_rm("/germy.mp3");
    printf("===== ESTADO DE DIRECTORIO =====\n");
    cz_ls("/");
    printf("===== VALORES RESULTANTES  =====\n");
    // Imprimimos los estados de cierre.
    printf("Estado de cierre 1: %i\nEstado de cierre 2: %i\n", close_state1, close_state2);
    // Imprimimos la cantidad de bytes escritos y leidos.
    printf("Cantidad de bytes leidos: %i\nCantidad de bytes escritos: %i\nCantidad original: %i\n", read_bytes, written_bytes, size);
    // Imprimimos los estados de existencia.
    printf("Estado de existencia 1: %i\nEstado de existencia 2: %i\n", exist_state1, exist_state2);
    // Imprimimos los estados de copia.
    printf("Estado de copia 1: %i\nEstado de copia 2: %i\n", copy_state1, copy_state2);
    // Imprimimos los estados de movimiento.
    printf("Estado de movimiento 1: %i\nEstado de movimiento 2: %i\n", move_state1, move_state2);
    // Imprimimos los estados de eliminación.
    printf("Estado de eliminación 1: %i\nEstado de eliminación 2: %i\n", remove_state1, remove_state2);
    // Liberamos todo.
    free(content);
    free(result);
};
