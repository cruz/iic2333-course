# IIC2333 - Sistemas Operativos y Redes - Tests P1

## Ayudantes: Germán Leandro Contreras Sagredo, Ricardo Esteban Schilling Broussaingaray

### Tests para la revisión del manejo del disco.

Para la revisión de este proyecto, se ejecutaron cinco _tests_ ubicados en la carpeta **tests**:

1. **main1.c:** _Test_ simple donde se revisa la lectura y escritura de archivos pequeños (esto es, no utilizan el bloque de direccionamiento indirecto).

2. **main2.c:** _Test_ más complejo donde se construyen dos archivos lo suficientemente grandes para hacer uso del bloque de direccionamiento indirecto. Además, el segundo archivo no es escrito al 100%, lo que se verá reflejado en la cantidad de bytes escritos retornada por la función.

3. **main3.c:** _Test_ intermedio que busca por sobretodo corroborar el funcionamiento de la existencia, copia y renombre de archivos.

4. **main4.c:** _Test_ equivalente a **main2.c**, pero haciendo uso de rutas intermedias.

5. **main5.c:** _Test_ equivalente a **main3.c**, pero haciendo uso de rutas intermedias y funciones de directorio.

A lo largo de los _tests_ se utiliza la función de listado (cz_ls) para poder corroborar los cambios correctos en el disco. Se hizo uso del archivo binario formateado (_simdiskformat_) para comprobar el funcionamiento correcto de su proyecto. No obstante, para los que no hayan implementado la escritura, se hace uso del disco con archivos subido con anterioridad (_simdiskfilled_). Por otra parte, **todos los _tests_ fueron modificados según los supuestos que hayan realizado en su proyecto**, así que no se generaron errores por no tomar eso en consideración. Finalmente, **los valores de retorno de cada método pueden variar de lo que está aquí expresado, ya que depende de cómo lo haya implementado cada grupo**. Lo importante era que fueran iguales a 0 o distintos de 0 según fuera el caso.

Además de los _tests_, se adjuntan los archivos de ejemplo (**examples/test[i]\_example.txt/png/mp3**), el resultado esperado al reconstruir el archivo (**results - files/test[i]\_result.txt/png/mp3**) y el _output_ generado de los archivos de prueba (**results - output/main[i]\_output.txt**).

Por último, en la carpeta **simdiskfilled files** se encuentran los archivos originales del disco lleno entregado.
