out1.txt es para scheduling non-preemptive.
out2.txt es para scheduling preemptive con quantum igual a 5.
out3.txt es para scheduling preemptive con quantum igual a 3.
