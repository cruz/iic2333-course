// Test para Tarea 01
// IIC2333 2019-2
// Ricardo Esteban Schilling Broussaingaray - @ichottmano

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/types.h>
#include <unistd.h>

void sigint_handler(int sig) {
	fprintf(stderr, "Me demoré mucho. meperd0n as¿\n");
	exit(3);
};

void sigterm_handler(int sig) {
	fprintf(stderr, "Me cancelaste. teperd0 no\n");
	exit(4);
};

int main(int argc, char *argv[]) {
	if (argc != 2) {
		fprintf(stderr, "Cantidad de parámetros incorrecta.\n");
		fprintf(stderr, "Parámetros esperados: 2\n");
		fprintf(stderr, "Parámetros recibidos: %d\n", argc);
		exit(1);
	};

	signal(SIGINT, sigint_handler);
	signal(SIGTERM, sigterm_handler);

	int seconds = atoi(argv[1]);

	if (seconds < 1) {
		fprintf(stderr, "Cantidad de segundos inválida o negativa.\n");
		exit(2);
	};

	for (int i = 0; i < seconds; i++) {
		fprintf(stdout, "PID: %i, Durmien2\n", getpid());
		sleep(1);
	};

	return 0;
};