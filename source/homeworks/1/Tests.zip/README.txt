Test 1:
./crexe input.txt output.txt 10

Test 2:
./crexe input.txt output.txt 10

Test 3:
./crexe input.txt output.txt