// Test para Tarea 01
// IIC2333 2019-2
// Ricardo Esteban Schilling Broussaingaray - @ichottmano

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/types.h>
#include <unistd.h>
#include <time.h>

void sigint_handler(int sig) {
	fprintf(stderr, "Me demoré mucho. uwu\n");
	exit(3);
};

void sigterm_handler(int sig) {
	fprintf(stderr, "Me cancelaste. rayos\n");
	exit(4);
};

int produce_result(int one, int two, int three, int index) {
	switch (index % 3) {
		case 0:
			return ((index * three) + (one ^ two));

		case 1:
			return ((index & two) | (two + one ^ three | two));

		case 2:
			return ((rand() % 120) + 3);

		default:
			return 0;
	};
};

int main(int argc, char *argv[]) {
	if (argc != 4) {
		fprintf(stderr, "Cantidad de parámetros incorrecta.\n");
		fprintf(stderr, "Parámetros esperados: 4\n");
		fprintf(stderr, "Parámetros recibidos: %d\n", argc);
		exit(1);
	};

	signal(SIGINT, sigint_handler);
	signal(SIGTERM, sigterm_handler);

	int one, two, three;

	one = atoi(argv[1]);
	two = atoi(argv[2]);
	three = atoi(argv[3]);

	int seconds = one + two - three;

	if (seconds < 0) {
		fprintf(stderr, "La combinación de parámetros es inválida.\n");
		exit(2);
	};

	srand(time(NULL));

	for (int i = 0; i < seconds; i++) {
		fprintf(stdout, "PID: %i, Result: %i\n", getpid(), produce_result(one, two, three, i));
		sleep(1);
	};

	return 0;
};