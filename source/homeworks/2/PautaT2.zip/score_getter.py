'''
IIC2333 2019-2 - Sistemas Operativos y Redes - Corrector de T2
Autor: Germán Leandro Contreras Sagredo
Descripción: El siguiente script obtiene el puntaje de la tarea de un/a
alumno/a, a partir de la pauta y del output generado por este/esta.
'''

# Librerías a utilizar.
from pathlib import Path # Existencia de archivos.
import sys               # Lectura de argumentos de la consola.

# Constantes a utilizar.
SS_TESTS = 4
LS_TESTS = 4
SS_SCORE = 2
LS_SCORE = 2

# Función para generar el diccionario de estadísticas dado un archivo.
def get_dict(input_file):
    # Diccionario a utilizar.
    stats = dict()
    with open(input_file, 'r') as f:
        line = f.readline()
        while line:
            # Separamos las estadísticas en una lista.
            process_stats = line.strip().split(',')
            # La llave será el nombre y el valor la lista con las estadísticas.
            stats[process_stats[0]] = [int(i) for i in process_stats[1:]]
            # Leemos la siguiente línea.
            line = f.readline()
    # Retornamos el diccionario.
    return stats

# Ejecución por consola.
if __name__ == "__main__":
    # El primer argumento corresponde a la carpeta del alumno/a.
    # El segundo argumento corresponde a la carpeta con las soluciones.
    student_path = sys.argv[1]
    corrector_path = sys.argv[2]
    # Puntaje por parte.
    scores = {'ss': 0, 'ls': 0}
    # Ponderación por test
    test_scores = {'ss': SS_SCORE/SS_TESTS, 'ls': LS_SCORE/LS_TESTS}
    # Revisamos cada test.
    for t in range(1,5):
        for m in ['ss', 'ls']:
            # Nombre del archivo de test.
            test_path = f"test{t}-{m}.csv"
            # Primero, verificamos que la tarea haya generado el output.
            # Si el archivo existe, se revisa.
            result_file = Path(f"{student_path}/{test_path}")
            if result_file.is_file():
                # Usamos try-except para el caso de los outputs vacíos o mal
                # escritos.
                try:
                    # Se leen los archivos y se obtienen sus diccionarios de
                    # estadísticas.
                    result = get_dict(f"{student_path}/{test_path}")
                    solution = get_dict(f"{corrector_path}/{test_path}")
                    # Primero se comparan las dimensiones para dar advertencias,
                    # en caso de existir diferencias.
                    # Número de procesos y de estadísticas.
                    n_processes = len(solution.keys())
                    n_stats = len(list(solution.values())[0])
                    # Advertencia 1 - #Procesos distinta a la esperada.
                    if len(result.keys()) != n_processes:
                        print(f"ADVERTENCIA: Test {t}-{m} tiene una cantidad "\
                              "de procesos distinta.")
                    # Advertencia 2 - #Estadísticas distinta a la esperada.
                    if len(list(result.values())[0]) != n_stats:
                        print(f"ADVERTENCIA: Test {t}-{m} tiene una cantidad "\
                              "de estadísticas distinta por proceso.")
                    # Ahora, vemos cada proceso y sus estadísticas.
                    # "total" nos servirá para ver el porcentaje correcto del
                    # test.
                    total = n_processes*n_stats
                    points = 0
                    for process, stats in result.items():
                        # Primero corroboramos que el proceso exista en la
                        # solución.
                        if process not in solution.keys():
                            print(f"ADVERTENCIA: Proceso {process} no es "\
                                  "parte de los procesos esperados en el "\
                                  "test {t}-{m}.")
                            # Si no existe, pasamos al siguiente (no suma
                            # puntaje).
                            continue                        
                        for i in range(n_stats):
                            # Aquí también se evalúa que sigan el orden correcto
                            # de las estadísticas. Si son iguales, aumenta el
                            # puntaje.
                            if stats[i] == solution[process][i]:
                                points += 1
                    # ----------------------------------------------------------
                    # Notar que si hubo un error (por ejemplo, cantidad de
                    # estadísticas mayor a la esperada), no se ejecutará la
                    # suma del puntaje y el test tendrá 0 puntos.
                    # ----------------------------------------------------------
                    # Sumamos el puntaje total y redondeamos con dos decimales
                    # por simplicidad.
                    percent = round(points/total,2)
                    # Obtenemos el porcentaje del puntaje total.
                    score_percent = percent*test_scores[m]
                    # Sumamos al puntaje de la sección que corresponda.
                    scores[m] += score_percent
                    print(f"Test {t}-{m}: {points}/{total} = "\
                          f"{score_percent} pts.")
                # El flujo anterior falló, por lo que se asume mala escritura
                # del archivo.
                except:
                    print(f"Test {t}-{m} tiene formato incorrecto. " \
                          f"Test {t}-{m}: 0 pts.")
            # En otro caso, hubo un problema al generar el archivo. Se asignan 0
            # puntos.
            else:
                print(f"Archivo {test_path} no fue generado. "\
                      f"Test {t}-{m}: 0 pts.")
    # Se imprimen los resultados finales.
    ss_score, ls_score = scores['ss'], scores['ls']
    print(f"Puntaje Short-Sighted: {ss_score}\n"\
          f"Puntaje Long-Sighted: {ls_score}")
