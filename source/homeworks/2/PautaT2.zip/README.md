# IIC2333 - Sistemas Operativos y Redes - Tests T2

## Ayudantes: Germán Leandro Contreras Sagredo, Ricardo Esteban Schilling Broussaingaray

### Tests para la revisión del _scheduler_.

Para la revisión de esta tarea se ejecutaron cuatro _tests_ -con las dos versiones del algoritmo para cada uno para cada uno- ubicados en la carpeta **tests**:

1. **test1.txt:** _Test_ simple correspondiente al primer caso de prueba subido, donde se revisa la ejecución básica de su programa. Evalúa la diferencia de la elección de un proceso según el modo de ejecución.

2. **test2.txt:** _Test_ simple correspondiente al segundo caso de prueba subido, donde se evalúa el caso en el que dos procesos que pueden interrumpir ingresan a la cola `READY` al mismo tiempo.

3. **test3.txt:** _Test_ que evalúa la ejecución de varios procesos con ráfagas más extensas (N = 2,...,6), evidenciando diferencias significativas según el modo de ejecución del _scheduler_.

4. **test4.txt:** _Test_ que evalúa el manejo correcto de interrupciones constantes y consecutivas de un conjunto considerable de procesos (31 en total).

Podrán notar que estos son, en general, de baja extensión y no suponen un mayor desafío de procesamiento. Esto, dado que el objetivo es corroborar que funcione lo más importante de forma correcta.

A continuación, los _outputs_ generados:

1. **_test 1 short-sighted_ - test1-ss.csv:** `./scheduler test1.txt test1-ss.csv ss`

2. **_test 1 long-sighted_ - test1-ls.csv:** `./scheduler test1.txt test1-ls.csv ls`

3. **_test 2 short-sighted_ - test2-ss.csv:** `./scheduler test2.txt test2-ss.csv ss`

4. **_test 2 long-sighted_ - test2-ls.csv:** `./scheduler test2.txt test2-ls.csv ls`

5. **_test 3 short-sighted_ - test3-ss.csv:** `./scheduler test3.txt test3-ss.csv ss`

6. **_test 3 long-sighted_ - test3-ls.csv:** `./scheduler test3.txt test3-ls.csv ls`

7. **_test 4 short-sighted_ - test4-ss.csv:** `./scheduler test4.txt test4-ss.csv ss`

8. **_test 4 long-sighted_ - test4-ls.csv:** `./scheduler test4.txt test4-ls.csv ls`

Pueden, finalmente, ver los resultados de sus _tests_ haciendo uso del script `score_getter.py`. Este requiere hacer uso de `Python 3.6` y se ejecuta desde consola como sigue:

```
py -3.6 score_getter.py /path/to/username/T2 /solutions
``` 

En este caso, se asume que `/path/to/username/T2` posee todos los archivos CSV generados por su programa según el detalle anterior.