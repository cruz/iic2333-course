# IIC2333 - Sistemas Operativos y Redes - Tests I2

## Ayudantes: Germán Leandro Contreras Sagredo, Raimundo José Herrera Sufán

### Parte 1 - doer

Para la revisión de esta sección, se ejecutaron ciertos _tests_. Sin embargo, en ciertos casos, para no perjudicar excesivamente, se probaron otros _tests_ para evitar situaciones en las que por consideraciones específicas suyas, fallaban las instrucciones. Para ambos _test_ se probó el paralelismo con distintos _n_:

1. **commands1.txt**: _Test_ con 7 comandos, 2 de ellos repetidos pero con diferentes argumentos. Se buscaba que la detección de los parámetros fuera la adecuada, y diferente para cada caso. 1 comando con múltiples argumentos, otro con argumentos del tipo `-flag` repetidos, para ver su manejo, en general no hubo problemas con ese caso. Y por último 1 comando que corría un ejecutable en el sistema, con ruta relativa, y que fallaba, para probar que reintentaran adecuadamente.
2. **commands2.txt**: El mismo comando de al final del _test_ anterior pero esta vez con ruta absoluta para evitar casos bordes. Se probó el comando incluido en el enunciado respecto a _DATE_, con el argumento en cuestión, que incluye comillas, por lo que su manejo no es trivial.

### Parte 2 - memory simulator

Para la revisión de esta tarea, se ejecutaron tres _tests_:

1. **test1.txt:** _Test_ simple con 30 accesos a memoria, de forma que se generaran 15 _hits_ en la TLB. El objetivo de este _test_ fue ver la construcción correcta de los niveles, el cálculo correcto de los óptimos por nivel, ver la correctitud de la lectura a través de los datos leídos desde data.bin y, finalmente, ver la correctitud de las estadísticas. Este _test_ fue el único que se corrió para los 5 niveles, el resto se ejecutó con **n = 5** (salvo los que no implementaron dicho nivel).

2. **test2.txt:** _Test_ más complejo construido a partir de test1.txt añadiendo 57 accesos a memoria más de forma que se llenara la TLB y se generara un reemplazo mediante LRU. El objetivo de este _test_ fue ver el funcionamiento correcto de la TLB y LRU para la TLB, además de ver la correctitud de las estadísticas.

3. **test3.txt:** _Test_ más complejo con un total de 261 accesos a memoria. La gracia de este _test_ es que la dirección física es igual a la dirección virtual **hasta** que se ocupan todos los _frames_. Esto ayuda a ver el reemplazo correcto mediante LRU de los _frames_ (desde el acceso a la dirección 65536 se debiese retornar a una dirección física igual a cero). El objetivo de este _test_ 
fue ver el funcionamiento correcto de LRU para los _frames_, además de ver la correctitud de las estadísticas y las traducciones.

Se adjuntan tanto los _tests_ como sus resultados esperados (**test[i]-results.txt**) y una breve explicación (**test[i]-explain.txt**). Además, el archivo **bits-per-level.txt** despliega las combinaciones aceptadas de bits por nivel como óptimo de la solución.