output1 es el resultado de text.txt para el primer mapreduce
output2 es el resultado de text.txt para el segundo mapreduce
output3 es el resultado de text.txt para el tercer mapreduce
output4 es el resultado de text2.txt para el primer mapreduce
output5 es el resultado de text2.txt para el segundo mapreduce
output6 es el resultado de text2.txt para el tercer mapreduce
