# IIC2333 - Sistemas Operativos y Redes - Tests T3

## Ayudantes: Germán Leandro Contreras Sagredo, Raimundo José Herrera Sufán

### Tests para la revisión del manejo del disco.

Para la revisión de esta tarea, se ejecutaron tres _tests_:

1. **test1.txt:** _Test_ simple donde se revisa la lectura y escritura de archivos pequeños (esto es, no utilizan el bloque de direccionamiento indirecto).

2. **test2.txt:** _Test_ más complejo donde se construyen dos archivos lo suficientemente grandes para hacer uso del bloque de direccionamiento indirecto. Además, el segundo archivo no es escrito al 100%, lo que se verá reflejado en la cantidad de bytes escritos retornada por la función.

3. **test3.txt:** _Test_ intermedio que busca por sobretodo corroborar el funcionamiento de la existencia, copia y renombre de archivos.

A lo largo de los _tests_ se utiliza la función de listado (cz_ls) para poder corroborar los cambios correctos en el disco. Se hizo uso de un archivo binario formateado para comprobar el funcionamiento correcto de su tarea. No obstante, para los que no hayan implementado la escritura, se hace uso del disco con archivos subido con anterioridad.

Se adjuntan los _tests_, los archivos de ejemplo (**examples/test[i]\_example.txt/png/mp3**), el resultado esperado al reconstruir el archivo (**results/test[i]\_result.txt/png/mp3**) y el _output_ generado de los archivos de prueba (**test[i]\_output.txt**).