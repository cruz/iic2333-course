#include <stdio.h>

int main(void) {
	printf("Hola! Soy un programa en C\n");
	return 0;
};