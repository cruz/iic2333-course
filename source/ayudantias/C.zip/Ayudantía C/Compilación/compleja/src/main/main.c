#include <stdio.h>
#include "../structs/structs.h"

int main(int argc, char *argv[]) {
	int length = atoi(argv[1]);
	int height = atoi(argv[2]);
	crear_tablero(length, height);
};