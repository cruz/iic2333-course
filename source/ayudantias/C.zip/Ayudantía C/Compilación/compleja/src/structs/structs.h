#include <stdlib.h>
#include <stdio.h>

typedef enum Color {
	Blanco,
	Negro
} Color;

typedef struct Celda {
	unsigned valor;
	Color color;
} Cell;

typedef struct Tablero {
	Cell **tablero;
	unsigned height;
	unsigned length;
} Table;

Table *crear_tablero(unsigned length, unsigned height);