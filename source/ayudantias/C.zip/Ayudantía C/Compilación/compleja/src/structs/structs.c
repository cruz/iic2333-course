#include "./structs.h"

Table *crear_tablero(unsigned length, unsigned height) {
	Table *new_tablero = malloc(sizeof(Table));
	// Creo un espacio en memoria para mi tablero
	new_tablero -> tablero = malloc(sizeof(Cell *) * length);
	// Ahora creo un puntero doble para mis casillas
	// Esto simboliza un arreglo de arreglos, una matriz
	for (unsigned i = 0; i < length; i++) {
		new_tablero -> tablero[i] = malloc(sizeof(Cell) * height);
		// Inicializo un arreglo en cada indice de nuestra matriz, para completarla
		for (unsigned j = 0; j < height; j++) {
			(new_tablero -> tablero[i][j]).color = (height + length) % 2;
			(new_tablero -> tablero[i][j]).valor = 0;
		};
	};

	printf("Tablero creado\nLargo: %d\nAlto: %d\n", length, height);

	return new_tablero;
};