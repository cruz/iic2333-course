#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>

int main(void) {
	printf("Mi PID es %u\n", getpid());
	for (;;) {
		usleep(500000);
	};
};