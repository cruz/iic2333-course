#include <stdlib.h>
#include <stdio.h>

int main(int argc, char const *argv[]) {
    // Este 'if' es para chequear que se ingresaron los argumentos requeridos
    if (argc != 3) {
        printf("Debes ingresar los parámetros N y M para la matriz.\n");
        printf("Ejemplo:  ./main 4 6\n");
        return -1;
    }

    int N = atoi(argv[1]);  // variable N (filas) es el primer argumento entregado como int
    int M = atoi(argv[2]);  // variable M (columnas) es el segundo argumento entregado como int

    // Crearemos una matriz de N x M, rellena con la suma de sus posiciones (i,j)
    // Como cada fila es un arreglo, necesitamos un puntero a punteros
    int** matriz = calloc(N, sizeof(int*));  // pedimos memoria para N filas

    for (int i = 0; i < N; i++) {
        int* fila = calloc(M, sizeof(int));  // pedimos memoria para los M elementos de cada fila
        for (int j = 0; j < M; j++) {
            fila[j] = i + j;
        }
        matriz[i] = fila;
    }

    // Imprimamos la matriz
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            printf("%i ", matriz[i][j]);
        }
        printf("\n");
    }

    // Liberamos cada fila
    for (int i = 0; i < N; i++) {
        free(matriz[i]);
    }
    // Finalmente liberamos la matriz
    free(matriz);

    return 0;
}
