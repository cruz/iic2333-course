#include <stdlib.h>
#include <stdio.h>
#include <string.h>

// struct que guarda información de un objecto 'circulo'
struct circulo {
    int diametro;
    char color[20];
};
typedef struct circulo Circulo;

// función que retorna el radio (float) de un círculo
float get_radio(Circulo c) {
    return c.diametro / 2.0;
}

// función que retorna el perímetro (float) de un círculo
float get_perimetro(Circulo c) {
    return 2 * 3.14 * get_radio(c);
}

// función que imprime la información del círculo
// no retorna nada (void)
void get_info(Circulo c) {
    printf("El circulo es de color %s y tiene diametro %i.\n", c.color, c.diametro);
}

int main(int argc, char const *argv[]) {
    Circulo c1;  // Nueva variable 'c1' del tipo 'Circulo'
    c1.diametro = 10;  // Asignamos 10 al atributo diámetro
    // c.color = "Azul";  <<< incorrecto: c.color es un arreglo -> no es asignable
    strcpy(c1.color, "Azul");  // Copiamos el string (arreglo de chars) "Azul" al atributo color
    get_info(c1);  // Imprimimos la información del círculo 1

    Circulo c2;  // Nueva variable 'c2' del tipo 'Circulo'
    c2.diametro = 15;  // Asignamos 15 al atributo diámetro
    strcpy(c2.color, "Rojo");  // Copiamos el string (arreglo de chars) "Rojo" al atributo color
    get_info(c2);  // Imprimimos la información del círculo 2

    printf("El circulo de color %s tiene perimetro %f.\n", c1.color, get_perimetro(c1));

    float perimetro2 = get_perimetro(c2);
    printf("El circulo de color %s tiene perimetro %f.\n", c2.color, perimetro2);


    Circulo* circulos = calloc(2, sizeof(Circulo));  // Pedimos memoria para un arreglo de 2 circulos
    printf("circulos -> %p\n", circulos);  // Imprimamos la direccion de memoria a la que apunta el puntero 'circulos'
    circulos[0] = c1;
    circulos[1] = c2;

    for (int i = 0; i < 2; i++) {
        circulos[i].diametro *= 2;
        get_info(circulos[i]);
    }

    free(circulos);  // Liberamos la memoria reservada para 'circulos'

    return 0;
}
