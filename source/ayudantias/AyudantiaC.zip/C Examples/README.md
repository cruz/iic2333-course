# Ayudantía C - IIC2333 - Sistemas Operativos y Redes

## Ayudantes: Germán Leandro Contreras Sagredo, Raimundo José Herrera Sufan

---

En esta carpeta encontrarán los siguientes programas:

* **exe1.c:** Programa en el que el usuario ingresa una frase y esta es impresa dos veces: Una de forma directa y otra a partir de una función externa.

* **exe2.c:** Programa en el que el usuario ingresa como *input* del programa el número de personas de una cola, para luego ingresar el nombre de cada una de ellas.


El objetivo de estos ejemplos es que se familiaricen con los comandos básicos de C, su sintáxis y su buen uso. Cualquier duda con respecto a los programas al correo de los ayudantes.
