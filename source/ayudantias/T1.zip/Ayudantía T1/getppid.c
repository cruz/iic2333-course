#include <stdio.h>
#include <unistd.h>

int main() {
	int pid1 = fork();
	if (pid1) {
		sleep(5);
		int pid2 = fork();
		if (pid2) {
			sleep(5)
			printf("¡Hola! Soy %d, mis hijos son %d y %d\n", getpid(), pid1, pid2);
		} else {
			printf("¡Hola! Soy %d, mi padre es %d", getpid(), getppid());
		}
	} else {
		printf("¡Hola! Soy %d, mi padre es %d", getpid(), getppid());
	};
};
