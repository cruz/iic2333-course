#include <stdio.h>
#include <string.h> // strtok().

int main() {
  // Texto de ejemplo.
  char example[30] = "hola,soy,el,germy,jejeje";
  // Delimitador.
  char delim[2] = ",";
  // El token será el texto que estaremos obteniendo a partir del delimitador.
  char * token;
  // Leemos el primer token y seguimos hasta terminar.
  token = strtok(example, delim);
   while(token != NULL) {
      printf("%s\n", token);
      // Le entregamos NULL para que nos entregue el siguiente token.
      token = strtok(NULL, delim);
   }
   return(0);
}
