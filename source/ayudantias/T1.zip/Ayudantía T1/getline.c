#include <stdlib.h> // getline().
#include <stdio.h> // Lectura de archivos.
int main() {
    char* line = NULL; // Definimos la línea como NULL.
    size_t size = 0; // Definimos el tamaño igual a cualquier número, como 0.
    // Abrimos un archivo de prueba y leemos las dos primeras líneas.
    FILE* fp = fopen("getline-test.txt", "r");
    getline(&line, &size, fp);
    printf("Línea 1: %s\n", line);
    getline(&line, &size, fp);
    printf("Línea 2: %s\n", line);
    // Si la línea partió como nula, el método se encarga de asignar memoria
    // y realocarla dinámicamente, por lo que debemos liberarla.
    free(line);
    fclose(fp);
    return 0;
}
