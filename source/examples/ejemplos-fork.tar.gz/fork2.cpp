/* 
   Compile with:
     g++ -o fork2 fork2.cpp

   Warning: This examples is written in C++.
   You can change it to pure C, if you want, but it is not needed

   Run (in Unix/Linux/MacOSX) with:
     ./fork2

*/


#include <iostream>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>


void Count(int start, char ch) {
  int i, j;
  for (i = start; i < 10; i++) {
    for (j = 0; j < 1000000; j++) ;
    std::cout << std::endl << ch << ": " << i;
  }
}

int main(int argc, char *arg[]) {
  int pid;
  int start = 0;
  pid=fork();
  if (pid > 0) { // parent continues here
    Count(start, 'P');
    //std::cout << "P: end" << std::endl;
    wait(NULL); // To get printing done before shell prompt shows
  }
  else if (pid == 0) // child got here!
    Count(start, 'C');
  else // only if there was a problem with fork
    exit(-1);
  std::cout << std::endl;
  return 0;
}

